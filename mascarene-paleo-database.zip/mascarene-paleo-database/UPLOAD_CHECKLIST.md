# BEFORE YOU UPLOAD TO GITHUB

1. Replace the CSV templates in `data/` with your current tables.
2. Update `README.md` with your name/contact details.
3. Update `CITATION.cff`.
4. Replace `YYYY-MM-DD` placeholders.
5. Update `reports/database_status.md`.
6. Add your first real entry to `CHANGELOG.md`.
7. Review `LICENSE.md`.
8. Remove any private correspondence, personal data, embargoed information, or restricted media.
9. Rename this folder to `mascarene-paleo-database` if desired.
10. Zip the folder or upload its contents directly to a new GitHub repository.
